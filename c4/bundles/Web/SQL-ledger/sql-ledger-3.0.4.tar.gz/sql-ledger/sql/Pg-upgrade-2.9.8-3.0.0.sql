--
update defaults set fldvalue = '3.0.0' where fldname = 'version';
