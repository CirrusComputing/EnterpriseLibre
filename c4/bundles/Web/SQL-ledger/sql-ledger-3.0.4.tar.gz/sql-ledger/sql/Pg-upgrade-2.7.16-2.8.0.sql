--
update defaults set fldvalue = '2.8.0' where fldname = 'version';
