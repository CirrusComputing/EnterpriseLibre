--
update defaults set fldvalue = '2.8.2' where fldname = 'version';
drop trigger del_recurring ON oe;
--

