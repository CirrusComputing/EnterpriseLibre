--
alter table defaults add projectnumber text;
--
update defaults set version = '2.6.7';
