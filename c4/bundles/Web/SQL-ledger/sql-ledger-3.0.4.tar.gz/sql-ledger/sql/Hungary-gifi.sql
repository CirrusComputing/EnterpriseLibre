--Hungarian GIFI / Magyar gy�jt�k�dok -- amelyek csak p�ldak�nt szolg�lnak
INSERT INTO gifi (accno,description) VALUES ('114','T�rgyi eszk�z�k');
INSERT INTO gifi (accno,description) VALUES ('119','T�rgyi eszk�z�k �CS');
INSERT INTO gifi (accno,description) VALUES ('261','�ruk');
INSERT INTO gifi (accno,description) VALUES ('311','Vev�k');
INSERT INTO gifi (accno,description) VALUES ('381','P�nzt�r');
INSERT INTO gifi (accno,description) VALUES ('384','Bank');
INSERT INTO gifi (accno,description) VALUES ('454','Sz�ll�t�k');
INSERT INTO gifi (accno,description) VALUES ('466','Visszaig�nyelhet� �FA');
INSERT INTO gifi (accno,description) VALUES ('467','Fizetend� �FA');
INSERT INTO gifi (accno,description) VALUES ('520','B�rleti d�j');
INSERT INTO gifi (accno,description) VALUES ('521','Telefon');
INSERT INTO gifi (accno,description) VALUES ('599','Egy�b k�lts�gek');
INSERT INTO gifi (accno,description) VALUES ('814','EL�B�');
INSERT INTO gifi (accno,description) VALUES ('870','�rfolyamvesztes�g');
INSERT INTO gifi (accno,description) VALUES ('911','�rbev�tel');
INSERT INTO gifi (accno,description) VALUES ('970','�rfolyamnyeres�g');
INSERT INTO gifi (accno,description) VALUES ('1','BEFEKTETETT ESZK�Z�K');
INSERT INTO gifi (accno,description) VALUES ('2','K�SZLETEK');
INSERT INTO gifi (accno,description) VALUES ('3','K�VETEL�SEK');
INSERT INTO gifi (accno,description) VALUES ('4','K�TELEZETTS�GEK');
INSERT INTO gifi (accno,description) VALUES ('5','K�LTS�GEK');
INSERT INTO gifi (accno,description) VALUES ('8','R�FORD�T�SOK');
INSERT INTO gifi (accno,description) VALUES ('9','BEV�TELEK');
--
