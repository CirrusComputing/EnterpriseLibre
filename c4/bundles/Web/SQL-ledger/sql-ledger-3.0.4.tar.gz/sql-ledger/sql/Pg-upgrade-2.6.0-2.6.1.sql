--
alter table jcitems add notes text;
--
update defaults set version = '2.6.1';

