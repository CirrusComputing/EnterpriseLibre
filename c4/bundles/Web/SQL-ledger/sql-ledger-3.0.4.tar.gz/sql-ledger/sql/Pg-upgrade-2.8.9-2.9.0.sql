--
update defaults set fldvalue = '2.9.0' where fldname = 'version';
