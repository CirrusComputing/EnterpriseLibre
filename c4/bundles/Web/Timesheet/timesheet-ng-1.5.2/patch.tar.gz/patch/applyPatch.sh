#!/bin/bash
#
# Created by Nimesh Jethwa <njethwa@cirruscomputing.com>
#
# November 2012
#
# SSO patch for Timesheet-NG-1.5.2

patch -u /var/lib/timesheet/class.AuthenticationManager.php < diff/class.AuthenticationManager.php.diff
patch -u /var/lib/timesheet/login.php < diff/login.php.diff
patch -u /var/lib/timesheet/timesheet_menu.inc < diff/timesheet_menu.inc.diff
patch -u /var/lib/timesheet/user_action.php < diff/user_action.php.diff 
