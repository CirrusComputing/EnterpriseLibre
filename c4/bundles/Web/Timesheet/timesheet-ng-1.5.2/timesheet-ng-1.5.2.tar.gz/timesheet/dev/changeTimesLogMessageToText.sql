 ALTER TABLE `timesheet_times` 
 CHANGE `log_message` `log_message` TEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL  