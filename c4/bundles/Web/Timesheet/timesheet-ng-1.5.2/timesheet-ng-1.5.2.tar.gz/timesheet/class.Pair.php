<?php
class Pair {
	var $value1;
	var $value2;

	function Pair($value1, $value2) {
		$this->value1 = $value1;
		$this->value2 = $value2;
	}
}
?>