#!/bin/bash
#
# Created by Nimesh Jethwa <njethwa@cirruscomputing.com>
#
# September 2012
#

#For SSO
patch -u /var/lib/vtigercrm/index.php < diff/index.php.diff
patch -u /var/lib/vtigercrm/adodb/drivers/adodb-ldap.inc.php < diff/adodb-ldap.inc.php.diff
patch -u /var/lib/vtigercrm/modules/Users/Authenticate.php < diff/Authenticate.php.diff
patch -u /var/lib/vtigercrm/modules/Users/CreateUserPrivilegeFile.php < diff/CreateUserPrivilegeFile.php.diff
patch -u /var/lib/vtigercrm/modules/Users/Users.php < diff/Users.php.diff
patch -u /var/lib/vtigercrm/modules/Users/Forms.php < diff/Forms.php.diff
#For default selection of 'group' when user tries to create an invoice
patch -u /var/lib/vtigercrm/Smarty/templates/Inventory/ProductDetails.tpl < diff/ProductDetails.tpl.diff
#For the sent mails to be stored in the users IMAP folder
patch -u /var/lib/vtigercrm/include/utils/CommonUtils.php < diff/CommonUtils.php.diff
patch -u /var/lib/vtigercrm/modules/Webmails/MailBox.php < diff/MailBox.php.diff
patch -u /var/lib/vtigercrm/modules/MailManager/src/controllers/MailController.php < diff/MailController.php.diff
patch -u /var/lib/vtigercrm/vtlib/Vtiger/Mailer.php < diff/Mailer.php.diff
patch -u /var/lib/vtigercrm/modules/Emails/mail.php < diff/mail.php.diff
patch -u /var/lib/vtigercrm/modules/Emails/Save.php < diff/Save.php.diff
#For Delete/expunge and Delay/Folders
patch -u /var/lib/vtigercrm/modules/MailManager/src/connectors/Connector.php < diff/Connector.php.diff
#For overriding the "Request URI too big" error
patch -u /var/lib/vtigercrm/Smarty/templates/MassEditForm.tpl < diff/MassEditForm.tpl.diff
#For having the default as "Organizations" in Lead Conversion Form instead of "Contacts"
patch -u /var/lib/vtigercrm/Smarty/templates/modules/Leads/ConvertLead.tpl < diff/ ConvertLead.tpl.diff
#For having the default as "Orgnizations" in Trouble Ticket Form instead of "Contacts" - Not Recommended for all orgs.
#patch -u /var/lib/vtigercrm/include/utils/EditViewUtils.php < diff/EditViewUtils.php.diff
