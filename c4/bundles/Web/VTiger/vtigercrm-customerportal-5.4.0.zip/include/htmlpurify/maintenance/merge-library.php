#!/usr/bin/php
<?php

/**
 * @file
 * Deprecated in favor of generate-standalone.php.
 */

require dirname(__FILE__) . '/generate-standalone.php';

// vim: et sw=4 sts=4
