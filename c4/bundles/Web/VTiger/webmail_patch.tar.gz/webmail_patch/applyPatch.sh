#!/bin/bash
#
# Created by Nimesh Jethwa <njethwa@cirruscomputing.com>
#
# October 2012
#
# This patch replaces Mail Manager with Webmail for vTiger 5.4

patch -u /var/lib/vtigercrm/Smarty/templates/Emails.tpl < diff/Emails.tpl.diff
patch -u /var/lib/vtigercrm/Smarty/templates/Webmails.tpl < diff/Webmails.tpl.diff
patch -u /var/lib/vtigercrm/Smarty/templates/modules/MailManager/index.tpl < diff/index.tpl.diff
patch -u /var/lib/vtigercrm/modules/Webmails/index.php < diff/index.php.diff
cp files/webmail_trash.gif /var/lib/vtigercrm/themes/softed/images/
cp files/opened_folder.gif /var/lib/vtigercrm/themes/softed/images/
