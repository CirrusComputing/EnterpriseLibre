#!/bin/bash
#
# Created by Nimesh Jethwa <njethwa@cirruscomputing.com>
#
# October 2012
#
# This patch replaces Webmail with MailManager for vTiger 5.4

patch -u /var/lib/vtigercrm/Smarty/templates/Emails.tpl < diff/Emails.tpl.diff
patch -u /var/lib/vtigercrm/Smarty/templates/Webmails.tpl < diff/Webmails.tpl.diff
patch -u /var/lib/vtigercrm/Smarty/templates/modules/MailManager/index.tpl < diff/index.tpl.diff
patch -u /var/lib/vtigercrm/modules/Webmails/index.php < diff/index.php.diff
