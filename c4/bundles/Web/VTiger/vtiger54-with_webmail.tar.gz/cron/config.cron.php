<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$VTIGER_CRON_CONFIGURATION = array(
        /*
         * Please refer to config.inc.php, copy the value of $application_unique_key here.
         * Example:
         * 'app_key' => '4cad1980873495f4dfdd4bd8b1204cfc7'
         */

        'app_key' => '6d0582c4a3183f28e1ab80cf1cca2b31'

);

?>
