#!/bin/sh

exec ./nxclient.sh -console "$@"

