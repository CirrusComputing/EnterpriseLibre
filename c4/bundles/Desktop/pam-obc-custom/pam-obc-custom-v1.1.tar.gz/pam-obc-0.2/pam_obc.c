/*
 *	Copyright(c) 2008,2009 by Paul Sery (pgsery@swcp.com) 
 *
 * 	Champ Clark (champ@softwink.com)
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License version 2 as 
 *	published by the Free Software Foundation.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <signal.h>

#include <security/pam_modules.h>

#define OBC_MSG_SIZE	4
#define OBC_ACTION_SIZE	255
#define USER_NOT_FOUND 1

int num_tries=3;

void sigtrap(int sig)
{
        switch(sig) {
        default:
        printf("Abort.\n");
        exit(1);
        }
}

struct actions {
	char *action;
	struct list  *next;
};

static char *
obc_action(const char *pam_uname)
{
	FILE *fp;
	int user_exists=0;
        char line[OBC_ACTION_SIZE];
        char *action=NULL;
        char *uname=NULL;

	fp = fopen("/etc/pam_obc.conf", "r");
	if (fp == NULL) {
		fp = fopen("/usr/local/etc/pam_obc.conf", "r");
		if (fp == NULL) {
			syslog(LOG_ALERT,"pam_obc[%d] ERROR: can't open pam_obc.conf",getpid());
			return (NULL);
		}
	}

	/* parse the user configuration file - specifies obc for each user */ 
        while (fgets(line, sizeof(line), fp) != NULL)
        {
		/* skip comments (currently, # can be anywhere in the line) */
		if ( strstr(line,"#") != NULL) 
			continue;

		/* strip trailing chars */
		if ( (action=strstr(line,"\r")) != NULL)
        	        *action = '\0';
		if ( (action=strstr(line,"\t")) != NULL)
        	        *action = '\0';

		/* extract user name */
		uname=line;
		action=strstr(line,":");
		*action='\0';

		action++;

		if ( strstr(uname,pam_uname) != NULL) {
			user_exists++;
			break;
		} 
	}
	fclose(fp);

	if (!user_exists) {
		syslog(LOG_ALERT,"pam_obc[%d] ERROR: pam user %s not found in pam_obc.conf",getpid(),pam_uname);
		action=NULL;
	}

	return(action);
}

char *
obc_gen(void)
{
	int i,ran,obc_size=OBC_MSG_SIZE;
	unsigned int seed;
	char *obc,cpool[] = "123456789";
	size_t nchars = sizeof(cpool) - 1;
	FILE *fp;

	fp = fopen("/dev/random","r");
	if (fp == NULL) {
		syslog(LOG_ALERT,"pam_obc[%d] ERROR: can't open /dev/random",getpid());
		return (NULL);
	}
	if ( fread(&seed,sizeof(seed),1,fp) == 0) {
		return (NULL);
		syslog(LOG_ALERT,"pam_obc[%d] ERROR: can't read /dev/random",getpid());
	}
	fclose(fp);

	/* generate out-of-band challenge (obc) */
	obc = (char *) malloc(obc_size+1);
	if (obc == NULL)
		return obc;

	srandom(seed);

	for (i=0;i < obc_size; i++) {
		ran = random();
		obc[i] = cpool[ran%nchars];
	}
	obc[obc_size] = '\0';

	return obc;
}


PAM_EXTERN int pam_sm_setcred (pam_handle_t *pamh,
			       int flags,
			       int argc,
			       const char **argv)
{
	return PAM_SUCCESS;
}

PAM_EXTERN int 
pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
	int retval;
	char *msg = NULL;
	char *obc = NULL;
	char *pam_uname = NULL;
	char *action = NULL;
	char act_str[OBC_ACTION_SIZE];	
	struct passwd *pw;
	struct pam_conv *conversation = NULL;
	struct pam_message message;
	struct pam_message *pmessage = &message;
	struct pam_response *response = NULL;

        signal (SIGHUP,  &sigtrap );
        signal (SIGINT,  &sigtrap );
        signal (SIGQUIT, &sigtrap );
        signal (SIGTERM, &sigtrap );
        signal (SIGABRT, &sigtrap );

	retval = pam_get_item (pamh, PAM_USER, (void **)&pam_uname);
	
	if(num_tries==3){
	if ( retval != PAM_SUCCESS) {
                syslog(LOG_ALERT,"pam_obc[%d] PAM user name error: %d",getpid(),retval);
		return (PAM_SERVICE_ERR);
	}
	if ((pw = getpwnam(pam_uname)) == NULL) {
                syslog(LOG_ALERT,"pam_obc[%d] pam user %s does not exist",getpid(),pam_uname);
		return (PAM_SERVICE_ERR);
	}

	/* get user's out-of-band action from pam_obc.conf */
	if ( (action = obc_action(pam_uname)) == NULL) {
		syslog(LOG_ALERT,"pam_obc[%d] ERROR: user %s unknown",getpid(),pam_uname);
		return(PAM_SERVICE_ERR);
	} 
	
	/* generate random out-of-band challenge */
	obc = obc_gen();
	if (obc == NULL) {
		syslog(LOG_ALERT,"pam_obc[%d] ERROR: obc_gen failed",getpid());
		return(PAM_SERVICE_ERR);
	} 

	/* deliver out-of-band challenge */
	snprintf(act_str, sizeof(act_str),
		"echo Hello %s,\"\n\"\"\n\"Your Double-Lock Password is: %s | %s",pam_uname,obc,action);
	if ( system(act_str) == -1) 
		syslog(LOG_ALERT,"pam_obc[%d] ERROR sending out-of-band challenge",getpid());

	msg = (char *) malloc(PAM_MAX_MSG_SIZE);
	if (msg == NULL) {
		syslog(LOG_ALERT, "unable to malloc\n");
		return(PAM_SERVICE_ERR);
	}
	}
	snprintf(msg, PAM_MAX_MSG_SIZE, "Enter Double-Lock Password: ");
	message.msg_style = PAM_PROMPT_ECHO_OFF;
	message.msg = msg;

	while(num_tries>0){	
	/* borrowed pam_get_item logic from pam_skey */
	retval = pam_get_item(pamh, PAM_CONV, (void **)&conversation);
	if (retval != PAM_SUCCESS) {
                syslog(LOG_ALERT,"pam_obc[%d] PAM get item error: %d",getpid(),retval);
		return(PAM_SERVICE_ERR);
	}

	conversation -> conv(1, (struct pam_message **)&pmessage,
		&response, conversation ->appdata_ptr);

	/* borrowed pam_set_item logic from pam_skey */
	retval = pam_set_item(pamh, PAM_AUTHTOK, response->resp);
	if (retval != PAM_SUCCESS) {
                syslog(LOG_ALERT,"pam_obc[%d] PAM set item error: %d",getpid(),retval);
		return(PAM_SERVICE_ERR);
	}

	if ((strcmp(obc,response->resp)) == 0) {
		syslog(LOG_ALERT,"pam_obc[%d] Authenticated user %s using out-of-band challenge",getpid(),pam_uname);
		retval=PAM_SUCCESS;
		break;
	} else {
		syslog(LOG_ALERT,"pam_obc[%d] Failed auth for user %s using out-of-band challenge",getpid(),pam_uname);
		retval=PAM_AUTH_ERR;
		num_tries--;	
	}
	}
/*
		free(msg);
		free(pmessage);
*/
return(retval);
}
