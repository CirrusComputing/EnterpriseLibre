#define VERSION "pamobc-0.2"
