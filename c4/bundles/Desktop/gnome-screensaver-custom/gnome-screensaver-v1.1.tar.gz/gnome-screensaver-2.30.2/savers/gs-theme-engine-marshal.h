
#ifndef __gs_theme_engine_marshal_MARSHAL_H__
#define __gs_theme_engine_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* BOOLEAN:BOXED (gs-theme-engine-marshal.list:1) */
extern void gs_theme_engine_marshal_BOOLEAN__BOXED (GClosure     *closure,
                                                    GValue       *return_value,
                                                    guint         n_param_values,
                                                    const GValue *param_values,
                                                    gpointer      invocation_hint,
                                                    gpointer      marshal_data);

G_END_DECLS

#endif /* __gs_theme_engine_marshal_MARSHAL_H__ */

