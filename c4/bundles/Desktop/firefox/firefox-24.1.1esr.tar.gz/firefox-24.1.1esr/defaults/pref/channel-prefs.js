//@line 2 "/builds/slave/rel-m-esr24-lx_bld-00000000000/build/browser/app/profile/channel-prefs.js"
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

pref("app.update.channel", "esr");
