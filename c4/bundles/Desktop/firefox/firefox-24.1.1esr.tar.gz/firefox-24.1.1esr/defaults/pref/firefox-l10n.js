//@line 36 "/build/buildd/firefox-3.6.23+build1+nobinonly/build-tree/mozilla/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/build/buildd/firefox-3.6.23+build1+nobinonly/build-tree/mozilla/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
