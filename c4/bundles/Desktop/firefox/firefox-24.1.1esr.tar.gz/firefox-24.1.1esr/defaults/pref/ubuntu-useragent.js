
pref ("general.useragent.vendor", "Ubuntu");
pref ("general.useragent.vendorSub", "10.04");
pref ("general.useragent.vendorComment", "lucid");

