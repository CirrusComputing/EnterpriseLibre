
#ifndef __e_cal_marshal_MARSHAL_H__
#define __e_cal_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* NONE:INT,STRING (e-cal-marshal.list:1) */
extern void e_cal_marshal_VOID__INT_STRING (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);
#define e_cal_marshal_NONE__INT_STRING	e_cal_marshal_VOID__INT_STRING

/* NONE:INT,BOOL (e-cal-marshal.list:2) */
extern void e_cal_marshal_VOID__INT_BOOLEAN (GClosure     *closure,
                                             GValue       *return_value,
                                             guint         n_param_values,
                                             const GValue *param_values,
                                             gpointer      invocation_hint,
                                             gpointer      marshal_data);
#define e_cal_marshal_NONE__INT_BOOL	e_cal_marshal_VOID__INT_BOOLEAN

/* NONE:INT,POINTER (e-cal-marshal.list:3) */
extern void e_cal_marshal_VOID__INT_POINTER (GClosure     *closure,
                                             GValue       *return_value,
                                             guint         n_param_values,
                                             const GValue *param_values,
                                             gpointer      invocation_hint,
                                             gpointer      marshal_data);
#define e_cal_marshal_NONE__INT_POINTER	e_cal_marshal_VOID__INT_POINTER

/* NONE:INT,POINTER,STRING (e-cal-marshal.list:4) */
extern void e_cal_marshal_VOID__INT_POINTER_STRING (GClosure     *closure,
                                                    GValue       *return_value,
                                                    guint         n_param_values,
                                                    const GValue *param_values,
                                                    gpointer      invocation_hint,
                                                    gpointer      marshal_data);
#define e_cal_marshal_NONE__INT_POINTER_STRING	e_cal_marshal_VOID__INT_POINTER_STRING

/* NONE:STRING,INT (e-cal-marshal.list:5) */
extern void e_cal_marshal_VOID__STRING_INT (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);
#define e_cal_marshal_NONE__STRING_INT	e_cal_marshal_VOID__STRING_INT

/* NONE:ENUM,ENUM (e-cal-marshal.list:6) */
extern void e_cal_marshal_VOID__ENUM_ENUM (GClosure     *closure,
                                           GValue       *return_value,
                                           guint         n_param_values,
                                           const GValue *param_values,
                                           gpointer      invocation_hint,
                                           gpointer      marshal_data);
#define e_cal_marshal_NONE__ENUM_ENUM	e_cal_marshal_VOID__ENUM_ENUM

G_END_DECLS

#endif /* __e_cal_marshal_MARSHAL_H__ */

