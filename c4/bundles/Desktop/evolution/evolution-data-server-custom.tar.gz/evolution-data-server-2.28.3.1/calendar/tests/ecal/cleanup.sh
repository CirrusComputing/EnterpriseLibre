#! /bin/sh
rm -rf $HOME/.evolution/calendar/local/OnThisComputer/Test*
rm -f tmp/*.out

