package EnterpriseLibre::CloudManager::View::Web;
use Moose;
use namespace::autoclean;

extends 'Catalyst::View';

=head1 NAME

EnterpriseLibre::CloudManager::View::Web - Catalyst View

=head1 DESCRIPTION

Catalyst View.

=head1 AUTHOR

Wolgemuth Greg

=head1 LICENSE

Free Open Source Solutions Inc. owns and reserves all rights, title, and
interest in and to this software in both machine and human readable
forms.

=cut

__PACKAGE__->meta->make_immutable;

