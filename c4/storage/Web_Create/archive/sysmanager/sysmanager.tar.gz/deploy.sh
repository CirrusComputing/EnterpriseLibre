#!/bin/bash
git archive HEAD > /tmp/acc.tar
cd /var/www/
rm -rf acc
mkdir acc
cd acc
tar -xf /tmp/acc.tar
cd ..
chown -R www-data:www-data acc
chmod -R 755 acc
