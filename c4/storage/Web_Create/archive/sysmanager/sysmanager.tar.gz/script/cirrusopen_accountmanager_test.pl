#!/usr/bin/env perl

use Catalyst::ScriptRunner;
Catalyst::ScriptRunner->run('CirrusOpen::AccountManager', 'Test');

1;

=head1 NAME

cirrusopen_accountmanager_test.pl - Catalyst Test

=head1 SYNOPSIS

cirrusopen_accountmanager_test.pl [options] uri

 Options:
   --help    display this help and exits

 Examples:
   cirrusopen_accountmanager_test.pl http://localhost/some_action
   cirrusopen_accountmanager_test.pl /some_action

 See also:
   perldoc Catalyst::Manual
   perldoc Catalyst::Manual::Intro

=head1 DESCRIPTION

Run a Catalyst action from the command line.

=head1 AUTHORS

Catalyst Contributors, see Catalyst.pm

=head1 COPYRIGHT

Free Open Source Solutions Inc. owns and reserves all rights, title, and
interest in and to this software in both machine and human readable
forms.

=cut
