#!/usr/bin/env perl

use Catalyst::ScriptRunner;
Catalyst::ScriptRunner->run('CirrusOpen::AccountManager', 'CGI');

1;

=head1 NAME

cirrusopen_accountmanager_cgi.pl - Catalyst CGI

=head1 SYNOPSIS

See L<Catalyst::Manual>

=head1 DESCRIPTION

Run a Catalyst application as a cgi script.

=head1 AUTHORS

Catalyst Contributors, see Catalyst.pm

=head1 COPYRIGHT

Free Open Source Solutions Inc. owns and reserves all rights, title, and
interest in and to this software in both machine and human readable
forms.

=cut

