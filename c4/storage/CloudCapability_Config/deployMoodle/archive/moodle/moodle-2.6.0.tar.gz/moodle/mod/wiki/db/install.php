<?php

function xmldb_wiki_install() {
    global $DB;

}