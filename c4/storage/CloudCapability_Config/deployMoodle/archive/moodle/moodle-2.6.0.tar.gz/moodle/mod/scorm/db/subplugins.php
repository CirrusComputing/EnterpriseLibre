<?php

$subplugins = array('scormreport'=>'mod/scorm/report');
