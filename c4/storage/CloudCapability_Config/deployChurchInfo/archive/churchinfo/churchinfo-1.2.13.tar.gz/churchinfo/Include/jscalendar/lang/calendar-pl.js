// Polish| dariush pietrzak, eyck@ghost.anime.pl
// ** I18N
Calendar._DN = new Array
("Niedziela",
 "Poniedzia�ek",
 "Wtorek",
 "�roda",
 "Czwartek",
 "Pi�tek",
 "Sobota",
 "Niedziela");
Calendar._MN = new Array
("Stycze�",
 "Luty",
 "Marzec",
 "Kwiecie�",
 "Maj",
 "Czerwiec",
 "Lipiec",
 "Sierpie�",
 "Wrzesie�",
 "Pa�dziernik",
 "Listopad",
 "Grudzie�");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Zmie� pierwszy dzie� tygodnia";
Calendar._TT["PREV_YEAR"] = "Poprzedni rok (przytrzymaj dla menu)";
Calendar._TT["PREV_MONTH"] = "Poprzedni miesi�c (przytrzymaj dla menu)";
Calendar._TT["GO_TODAY"] = "Id� do dzisiaj";
Calendar._TT["NEXT_MONTH"] = "Nast�pny miesi�c (przytrzymaj dla menu)";
Calendar._TT["NEXT_YEAR"] = "Nast�pny rok (przytrzymaj dla menu)";
Calendar._TT["SEL_DATE"] = "Wybierz dat�";
Calendar._TT["DRAG_TO_MOVE"] = "Przeci�gnij by przesun��";
Calendar._TT["PART_TODAY"] = " (dzisiaj)";
Calendar._TT["MON_FIRST"] = "Wy�wietl poniedzia�ek jako pierwszy";
Calendar._TT["SUN_FIRST"] = "Wy�wietl niedziel� jako pierwsz�";
Calendar._TT["CLOSE"] = "Zamknij";
Calendar._TT["TODAY"] = "Dzisiaj";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "D, M d";

Calendar._TT["WK"] = "wk";
