<?php
	$sPageTitle = "Wiki Documentation";
	require "Include/Header.php";
?>

<div class="Help_Section">
	<div class="Help_Header">ChurchInfo Wiki</div>

	<table width="100%" class="LightShadedBox"><tr><td>Up-to-date documentation is maintained by the ChurchInfo community at the <a href="http://www.churchdb.org/dokuwiki-2007-06-26b/doku.php">ChurchInfo Documentation Wiki</a>. If you would like to contribute to the ducumentation effort, please contact the developers on the <a href="https://sourceforge.net/projects/churchinfo/forums">Churchinfo support forums</a></td></tr></table>

<?php
	require "Include/Footer.php";
?>
