<select name="Country">
	<option value="">Unassigned</option>
	<option value="">--------------------</option>
	<option value="United States"<?php if ($sCountry == "United States") { echo " selected"; } ?>>United States
	<option value="Canada"<?php if ($sCountry == "Canada") { echo " selected"; } ?>>Canada
	<option value="Afghanistan"<?php if ($sCountry == "Afghanistan") { echo " selected"; } ?>>Afghanistan
	<option value="Albania"<?php if ($sCountry == "Albania") { echo " selected"; } ?>>Albania
	<option value="Algeria "<?php if ($sCountry == "Algeria") { echo " selected"; } ?>>Algeria 
	<option value="Andorra"<?php if ($sCountry == "Andorra") { echo " selected"; } ?>>Andorra
	<option value="Angola"<?php if ($sCountry == "Angola") { echo " selected"; } ?>>Angola
	<option value="Anguilla/St. Kitt"<?php if ($sCountry == "Anguilla/St. Kitt") { echo " selected"; } ?>>Anguilla/St. Kitt
	<option value="Antarctica"<?php if ($sCountry == "Antarctica") { echo " selected"; } ?>>Antarctica
	<option value="Antigua/Barbuda"<?php if ($sCountry == "Antigua/Barbuda") { echo " selected"; } ?>>Antigua/Barbuda
	<option value="Argentina"<?php if ($sCountry == "Argentina") { echo " selected"; } ?>>Argentina
	<option value="Armenia"<?php if ($sCountry == "Armenia") { echo " selected"; } ?>>Armenia
	<option value="Aruba"<?php if ($sCountry == "Aruba") { echo " selected"; } ?>>Aruba
	<option value="Australia"<?php if ($sCountry == "Australia") { echo " selected"; } ?>>Australia
	<option value="Austria"<?php if ($sCountry == "Austria") { echo " selected"; } ?>>Austria
	<option value="Azerbaijan"<?php if ($sCountry == "Azerbaijan") { echo " selected"; } ?>>Azerbaijan
	<option value="Bahamas"<?php if ($sCountry == "Bahamas") { echo " selected"; } ?>>Bahamas
	<option value="Bahrain"<?php if ($sCountry == "Bahrain") { echo " selected"; } ?>>Bahrain
	<option value="Bangladesh"<?php if ($sCountry == "Bangladesh") { echo " selected"; } ?>>Bangladesh
	<option value="Barbados"<?php if ($sCountry == "Barbados") { echo " selected"; } ?>>Barbados
	<option value="Belarus"<?php if ($sCountry == "Belarus") { echo " selected"; } ?>>Belarus
	<option value="Belgium"<?php if ($sCountry == "Belgium") { echo " selected"; } ?>>Belgium
	<option value="Belize"<?php if ($sCountry == "Belize") { echo " selected"; } ?>>Belize
	<option value="Benin"<?php if ($sCountry == "Benin") { echo " selected"; } ?>>Benin
	<option value="Bermuda"<?php if ($sCountry == "Bermuda") { echo " selected"; } ?>>Bermuda
	<option value="Bhutan"<?php if ($sCountry == "Bhutan") { echo " selected"; } ?>>Bhutan
	<option value="Bolivia"<?php if ($sCountry == "Bolivia") { echo " selected"; } ?>>Bolivia
	<option value="Bosnia Hersegovi"<?php if ($sCountry == "Bosnia Hersegovi") { echo " selected"; }?>>Bosnia Hersegovi
	<option value="Botswana"<?php if ($sCountry == "Botswana") { echo " selected"; } ?>>Botswana
	<option value="Bouvet Island"<?php if ($sCountry == "Bouvet Island") { echo " selected"; }?>>Bouvet Island
	<option value="Brazil"<?php if ($sCountry == "Brazil") { echo " selected"; } ?>>Brazil
	<option value="British Virgin Islands"<?php if ($sCountry == "British Virgin Islands") { echo " selected"; }?>>British Virgin Islands
	<option value="Brunei"<?php if ($sCountry == "Brunei") { echo " selected"; } ?>>Brunei
	<option value="Bulgaria"<?php if ($sCountry == "Bulgaria") { echo " selected"; } ?>>Bulgaria
	<option value="Burkina Faso"<?php if ($sCountry == "Burkina Faso") { echo " selected"; }?>>Burkina Faso
	<option value="Burundi"<?php if ($sCountry == "Burundi") { echo " selected"; } ?>>Burundi
	<option value="Cambodia"<?php if ($sCountry == "Cambodia") { echo " selected"; } ?>>Cambodia
	<option value="Cameroon"<?php if ($sCountry == "Cameroon") { echo " selected"; } ?>>Cameroon
	<option value="Cape Verde"<?php if ($sCountry == "Cape Verde") { echo " selected"; }?>>Cape Verde
	<option value="Cayman Islands"<?php if ($sCountry == "Cayman Islands") { echo " selected"; }?>>Cayman Islands
	<option value="Central Africa"<?php if ($sCountry == "Central Africa") { echo " selected"; }?>>Central Africa
	<option value="Chad"<?php if ($sCountry == "Chad") { echo " selected"; } ?>>Chad
	<option value="Chile"<?php if ($sCountry == "Chile") { echo " selected"; } ?>>Chile
	<option value="China"<?php if ($sCountry == "China") { echo " selected"; } ?>>China
	<option value="Christmas Island"<?php if ($sCountry == "Christmas Island") { echo " selected"; }?>>Christmas Island
	<option value="Cocos/Keeling Island"<?php if ($sCountry == "Cocos/Keeling Island") { echo " selected"; }?>>Cocos/Keeling Island
	<option value="Colombia "<?php if ($sCountry == "Colombia") { echo " selected"; } ?>>Colombia 
	<option value="Comoros Island"<?php if ($sCountry == "Comoros Island") { echo " selected"; }?>>Comoros Island
	<option value="Congo Brazzavill"<?php if ($sCountry == "Congo Brazzavill") { echo " selected"; }?>>Congo Brazzavill
	<option value="Cook Island"<?php if ($sCountry == "Cook Island") { echo " selected"; }?>>Cook Island
	<option value="Costa Rica"<?php if ($sCountry == "Costa Rica") { echo " selected"; }?>>Costa Rica
	<option value="Cote D'Ivoire"<?php if ($sCountry == "Cote D'Ivoire") { echo " selected"; }?>>Cote D'Ivoire
	<option value="Croatia"<?php if ($sCountry == "Croatia") { echo " selected"; } ?>>Croatia
	<option value="Cuba"<?php if ($sCountry == "Cuba") { echo " selected"; } ?>>Cuba
	<option value="Cyprus"<?php if ($sCountry == "Cyprus") { echo " selected"; } ?>>Cyprus
	<option value="Czech"<?php if ($sCountry == "Czech") { echo " selected"; } ?>>Czech
	<option value="Denmark"<?php if ($sCountry == "Denmark") { echo " selected"; } ?>>Denmark
	<option value="Djibouti"<?php if ($sCountry == "Djibouti") { echo " selected"; } ?>>Djibouti
	<option value="Dominica"<?php if ($sCountry == "Dominica") { echo " selected"; } ?>>Dominica
	<option value="Dominican Republic"<?php if ($sCountry == "Dominican Republic") { echo " selected"; }?>>Dominican Republic
	<option value="East Timor"<?php if ($sCountry == "East Timor") { echo " selected"; }?>>East Timor
	<option value="Ecuador"<?php if ($sCountry == "Ecuador") { echo " selected"; } ?>>Ecuador
	<option value="Egypt"<?php if ($sCountry == "Egypt") { echo " selected"; } ?>>Egypt
	<option value="El Salvador"<?php if ($sCountry == "El Salvador") { echo " selected"; }?>>El Salvador
	<option value="Equatorial Guinea"<?php if ($sCountry == "Equatorial Guinea") { echo " selected"; }?>>Equatorial Guinea
	<option value="Eritrea"<?php if ($sCountry == "Eritrea") { echo " selected"; } ?>>Eritrea
	<option value="Estonia"<?php if ($sCountry == "Estonia") { echo " selected"; } ?>>Estonia
	<option value="Ethiopia"<?php if ($sCountry == "Ethiopia") { echo " selected"; } ?>>Ethiopia
	<option value="Falkland Islands"<?php if ($sCountry == "Falkland Islands") { echo " selected"; }?>>Falkland Islands
	<option value="Faroe Islands"<?php if ($sCountry == "Faroe Islands") { echo " selected"; }?>>Faroe Islands
	<option value="Fiji Islands"<?php if ($sCountry == "Fiji Islands") { echo " selected"; }?>>Fiji Islands
	<option value="Finland"<?php if ($sCountry == "Finland") { echo " selected"; } ?>>Finland
	<option value="France"<?php if ($sCountry == "France") { echo " selected"; } ?>>France
	<option value="French Guyana"<?php if ($sCountry == "French Guyana") { echo " selected"; }?>>French Guyana
	<option value="French Polynesia"<?php if ($sCountry == "French Polynesia") { echo " selected"; }?>>French Polynesia
	<option value="French Southern"<?php if ($sCountry == "French Southern") { echo " selected"; }?>>French Southern
	<option value="Gabon"<?php if ($sCountry == "Gabon") { echo " selected"; } ?>>Gabon
	<option value="Gambia"<?php if ($sCountry == "Gambia") { echo " selected"; } ?>>Gambia
	<option value="Georgia"<?php if ($sCountry == "Georgia") { echo " selected"; } ?>>Georgia
	<option value="Germany"<?php if ($sCountry == "Germany") { echo " selected"; } ?>>Germany
	<option value="Ghana"<?php if ($sCountry == "Ghana") { echo " selected"; } ?>>Ghana
	<option value="Gibraltar"<?php if ($sCountry == "Gibraltar") { echo " selected"; } ?>>Gibraltar
	<option value="Great Britain"<?php if ($sCountry == "Great Britain") { echo " selected"; }?>>Great Britain
	<option value="Greece"<?php if ($sCountry == "Greece") { echo " selected"; } ?>>Greece
	<option value="Greenland"<?php if ($sCountry == "Greenland") { echo " selected"; } ?>>Greenland
	<option value="Grenada"<?php if ($sCountry == "Grenada") { echo " selected"; } ?>>Grenada
	<option value="Guadaloupe/St. Martin"<?php if ($sCountry == "Guadaloupe/St. Martin") { echo " selected"; }?>>Guadaloupe/St. Martin
	<option value="Guam"<?php if ($sCountry == "Guam") { echo " selected"; } ?>>Guam
	<option value="Guatemala"<?php if ($sCountry == "Guatemala") { echo " selected"; } ?>>Guatemala
	<option value="Guinea"<?php if ($sCountry == "Guinea") { echo " selected"; } ?>>Guinea
	<option value="Guinea Bissau"<?php if ($sCountry == "Guinea Bissau") { echo " selected"; }?>>Guinea Bissau
	<option value="Guyana"<?php if ($sCountry == "Guyana") { echo " selected"; } ?>>Guyana
	<option value="Haiti"<?php if ($sCountry == "Haiti") { echo " selected"; } ?>>Haiti
	<option value="Heard/McDonald Island"<?php if ($sCountry == "Heard/McDonald Island") { echo " selected"; }?>>Heard/McDonald Island
	<option value="Honduras"<?php if ($sCountry == "Honduras") { echo " selected"; } ?>>Honduras
	<option value="Hong Kong"<?php if ($sCountry == "Hong Kong") { echo " selected"; }?>>Hong Kong
	<option value="Hungary"<?php if ($sCountry == "Hungary") { echo " selected"; } ?>>Hungary
	<option value="Iceland"<?php if ($sCountry == "Iceland") { echo " selected"; } ?>>Iceland
	<option value="India"<?php if ($sCountry == "India") { echo " selected"; } ?>>India
	<option value="Indian Ocean Island"<?php if ($sCountry == "Indian Ocean Island") { echo " selected"; }?>>Indian Ocean Island
	<option value="Indonesia"<?php if ($sCountry == "Indonesia") { echo " selected"; } ?>>Indonesia
	<option value="Iran"<?php if ($sCountry == "Iran") { echo " selected"; } ?>>Iran
	<option value="Iraq"<?php if ($sCountry == "Iraq") { echo " selected"; } ?>>Iraq
	<option value="Ireland"<?php if ($sCountry == "Ireland") { echo " selected"; } ?>>Ireland
	<option value="Israel"<?php if ($sCountry == "Israel") { echo " selected"; } ?>>Israel
	<option value="Italy"<?php if ($sCountry == "Italy") { echo " selected"; } ?>>Italy
	<option value="Jamaica"<?php if ($sCountry == "Jamaica") { echo " selected"; } ?>>Jamaica
	<option value="Japan"<?php if ($sCountry == "Japan") { echo " selected"; } ?>>Japan
	<option value="Jordan"<?php if ($sCountry == "Jordan") { echo " selected"; } ?>>Jordan
	<option value="Kazakhstan"<?php if ($sCountry == "Kazakhstan") { echo " selected"; } ?>>Kazakhstan
	<option value="Kenya"<?php if ($sCountry == "Kenya") { echo " selected"; } ?>>Kenya
	<option value="Kiribati"<?php if ($sCountry == "Kiribati") { echo " selected"; } ?>>Kiribati
	<option value="Korea"<?php if ($sCountry == "Korea") { echo " selected"; } ?>>Korea
	<option value="Kuwait"<?php if ($sCountry == "Kuwait") { echo " selected"; } ?>>Kuwait
	<option value="Kyrgyzstan"<?php if ($sCountry == "Kyrgyzstan") { echo " selected"; } ?>>Kyrgyzstan
	<option value="Laos"<?php if ($sCountry == "Laos") { echo " selected"; } ?>>Laos
	<option value="Latvia"<?php if ($sCountry == "Latvia") { echo " selected"; } ?>>Latvia
	<option value="Lebanon"<?php if ($sCountry == "Lebanon") { echo " selected"; } ?>>Lebanon
	<option value="Lesoto"<?php if ($sCountry == "Lesoto") { echo " selected"; } ?>>Lesoto
	<option value="Liberia"<?php if ($sCountry == "Liberia") { echo " selected"; } ?>>Liberia
	<option value="Libyan Arab Jama"<?php if ($sCountry == "Libyan Arab Jama") { echo " selected"; }?>>Libyan Arab Jama
	<option value="Liechtenstein"<?php if ($sCountry == "Liechtenstein") { echo " selected"; } ?>>Liechtenstein
	<option value="Lithuania"<?php if ($sCountry == "Lithuania") { echo " selected"; } ?>>Lithuania
	<option value="Luxemburg"<?php if ($sCountry == "Luxemburg") { echo " selected"; } ?>>Luxemburg
	<option value="Macau"<?php if ($sCountry == "Macau") { echo " selected"; } ?>>Macau
	<option value="Macedonia"<?php if ($sCountry == "Macedonia") { echo " selected"; } ?>>Macedonia
	<option value="Madagascar"<?php if ($sCountry == "Madagascar") { echo " selected"; } ?>>Madagascar
	<option value="Malawi"<?php if ($sCountry == "Malawi") { echo " selected"; } ?>>Malawi
	<option value="Malaysia"<?php if ($sCountry == "Malaysia") { echo " selected"; } ?>>Malaysia
	<option value="Maldives"<?php if ($sCountry == "Maldives") { echo " selected"; } ?>>Maldives
	<option value="Mali"<?php if ($sCountry == "Mali") { echo " selected"; } ?>>Mali
	<option value="Malta"<?php if ($sCountry == "Malta") { echo " selected"; } ?>>Malta
	<option value="Marocco"<?php if ($sCountry == "Marocco") { echo " selected"; } ?>>Marocco
	<option value="Marshall Island"<?php if ($sCountry == "Marshall Island") { echo " selected"; }?>>Marshall Island
	<option value="Martinique"<?php if ($sCountry == "Martinique") { echo " selected"; } ?>>Martinique
	<option value="Mauritania"<?php if ($sCountry == "Mauritania") { echo " selected"; } ?>>Mauritania
	<option value="Mauritius"<?php if ($sCountry == "Mauritius") { echo " selected"; } ?>>Mauritius
	<option value="Mayotte"<?php if ($sCountry == "Mayotte") { echo " selected"; } ?>>Mayotte
	<option value="Mexico"<?php if ($sCountry == "Mexico") { echo " selected"; } ?>>Mexico
	<option value="Micronesia-Feder"<?php if ($sCountry == "Micronesia-Feder") { echo " selected"; }?>>Micronesia-Feder
	<option value="Moldova"<?php if ($sCountry == "Moldova") { echo " selected"; } ?>>Moldova
	<option value="Monaco"<?php if ($sCountry == "Monaco") { echo " selected"; } ?>>Monaco
	<option value="Mongolia"<?php if ($sCountry == "Mongolia") { echo " selected"; } ?>>Mongolia
	<option value="Montserrat"<?php if ($sCountry == "Montserrat") { echo " selected"; } ?>>Montserrat
	<option value="Mozambique"<?php if ($sCountry == "Mozambique") { echo " selected"; } ?>>Mozambique
	<option value="Myanmar"<?php if ($sCountry == "Myanmar") { echo " selected"; } ?>>Myanmar
	<option value="Namibia"<?php if ($sCountry == "Namibia") { echo " selected"; } ?>>Namibia
	<option value="Nauru"<?php if ($sCountry == "Nauru") { echo " selected"; } ?>>Nauru
	<option value="Nepal"<?php if ($sCountry == "Nepal") { echo " selected"; } ?>>Nepal
	<option value="Netherlands"<?php if ($sCountry == "Netherlands") { echo " selected"; } ?>>Netherlands
	<option value="Netherlands Anti"<?php if ($sCountry == "Netherlands Anti") { echo " selected"; }?>>Netherlands Anti
	<option value="New Caledonia"<?php if ($sCountry == "New Caledonia") { echo " selected"; }?>>New Caledonia
	<option value="New Zealand"<?php if ($sCountry == "New Zealand") { echo " selected"; }?>>New Zealand
	<option value="Nicaragua"<?php if ($sCountry == "Nicaragua") { echo " selected"; } ?>>Nicaragua
	<option value="Niger"<?php if ($sCountry == "Niger") { echo " selected"; } ?>>Niger
	<option value="Nigeria"<?php if ($sCountry == "Nigeria") { echo " selected"; } ?>>Nigeria
	<option value="Niue"<?php if ($sCountry == "Niue") { echo " selected"; } ?>>Niue
	<option value="Norfolk Island"<?php if ($sCountry == "Norfolk Island") { echo " selected"; }?>>Norfolk Island
	<option value="Northern Ireland"<?php if ($sCountry == "Northern Ireland") { echo " selected"; }?>>Northern Ireland
	<option value="Northern Mariana"<?php if ($sCountry == "Northern Mariana") { echo " selected"; }?>>Northern Mariana
	<option value="Norway"<?php if ($sCountry == "Norway") { echo " selected"; } ?>>Norway
	<option value="Oman"<?php if ($sCountry == "Oman") { echo " selected"; } ?>>Oman
	<option value="Pakistan"<?php if ($sCountry == "Pakistan") { echo " selected"; } ?>>Pakistan
	<option value="Palau-Republic Of"<?php if ($sCountry == "Palau-Republic Of") { echo " selected"; }?>>Palau-Republic Of
	<option value="Panama"<?php if ($sCountry == "Panama") { echo " selected"; } ?>>Panama
	<option value="Papua New Guinea"<?php if ($sCountry == "Papua New Guinea") { echo " selected"; }?>>Papua New Guinea
	<option value="Paraguay"<?php if ($sCountry == "Paraguay") { echo " selected"; } ?>>Paraguay
	<option value="Peru"<?php if ($sCountry == "Peru") { echo " selected"; } ?>>Peru
	<option value="Philippines"<?php if ($sCountry == "Philippines") { echo " selected"; } ?>>Philippines
	<option value="Pitcairn"<?php if ($sCountry == "Pitcairn") { echo " selected"; } ?>>Pitcairn
	<option value="Poland"<?php if ($sCountry == "Poland") { echo " selected"; } ?>>Poland
	<option value="Portugal"<?php if ($sCountry == "Portugal") { echo " selected"; } ?>>Portugal
	<option value="Qatar"<?php if ($sCountry == "Qatar") { echo " selected"; } ?>>Qatar
	<option value="Reunion Island"<?php if ($sCountry == "Reunion Island") { echo " selected"; }?>>Reunion Island
	<option value="Romania"<?php if ($sCountry == "Romania") { echo " selected"; } ?>>Romania
	<option value="Russia"<?php if ($sCountry == "Russia") { echo " selected"; } ?>>Russia
	<option value="Rwanda"<?php if ($sCountry == "Rwanda") { echo " selected"; } ?>>Rwanda
	<option value="Samoa American"<?php if ($sCountry == "Samoa American") { echo " selected"; }?>>Samoa American
	<option value="Samoa Western"<?php if ($sCountry == "Samoa Western") { echo " selected"; }?>>Samoa Western
	<option value="San Marino"<?php if ($sCountry == "San Marino") { echo " selected"; }?>>San Marino
	<option value="Sao Tome and Pri"<?php if ($sCountry == "Sao Tome and Pri") { echo " selected"; }?>>Sao Tome and Pri
	<option value="Saudi Arabia"<?php if ($sCountry == "Saudi Arabia") { echo " selected"; }?>>Saudi Arabia
	<option value="Senegal"<?php if ($sCountry == "Senegal") { echo " selected"; } ?>>Senegal
	<option value="Seychelles Island"<?php if ($sCountry == "Seychelles Island") { echo " selected"; }?>>Seychelles Islan
	<option value="Sierra Leone"<?php if ($sCountry == "Sierra Leone") { echo " selected"; }?>>Sierra Leone
	<option value="Singapore"<?php if ($sCountry == "Singapore") { echo " selected"; } ?>>Singapore
	<option value="Slovakia"<?php if ($sCountry == "Slovakia") { echo " selected"; } ?>>Slovakia
	<option value="Slovenia"<?php if ($sCountry == "Slovenia") { echo " selected"; } ?>>Slovenia
	<option value="Solomon Island"<?php if ($sCountry == "Solomon Island") { echo " selected"; }?>>Solomon Island
	<option value="Somalia"<?php if ($sCountry == "Somalia") { echo " selected"; } ?>>Somalia
	<option value="South Africa"<?php if ($sCountry == "South Africa") { echo " selected"; }?>>South Africa
	<option value="Spain"<?php if ($sCountry == "Spain") { echo " selected"; } ?>>Spain
	<option value="Sri Lanka"<?php if ($sCountry == "Sri Lanka") { echo " selected"; }?>>Sri Lanka
	<option value="St Pierre Et Miq"<?php if ($sCountry == "St Pierre Et Miq") { echo " selected"; }?>>St Pierre Et Miq
	<option value="St Vincent-Grena"<?php if ($sCountry == "St Vincent-Grena") { echo " selected"; }?>>St Vincent-Grena
	<option value="St. Helena"<?php if ($sCountry == "St. Helena") { echo " selected"; }?>>St. Helena
	<option value="St. Lucia"<?php if ($sCountry == "St. Lucia") { echo " selected"; }?>>St. Lucia
	<option value="St.Kitts/Nevis"<?php if ($sCountry == "St.Kitts/Nevis") { echo " selected"; }?>>St.Kitts/Nevis
	<option value="Sudan"<?php if ($sCountry == "Sudan") { echo " selected"; } ?>>Sudan
	<option value="Surinam"<?php if ($sCountry == "Surinam") { echo " selected"; } ?>>Surinam
	<option value="Svalbard"<?php if ($sCountry == "Svalbard") { echo " selected"; } ?>>Svalbard
	<option value="Swaziland"<?php if ($sCountry == "Swaziland") { echo " selected"; } ?>>Swaziland
	<option value="Sweden"<?php if ($sCountry == "Sweden") { echo " selected"; } ?>>Sweden
	<option value="Switzerland"<?php if ($sCountry == "Switzerland") { echo " selected"; } ?>>Switzerland
	<option value="Syria"<?php if ($sCountry == "Syria") { echo " selected"; } ?>>Syria
	<option value="Taiwan"<?php if ($sCountry == "Taiwan") { echo " selected"; } ?>>Taiwan
	<option value="Tajikistan"<?php if ($sCountry == "Tajikistan") { echo " selected"; } ?>>Tajikistan
	<option value="Tanzania"<?php if ($sCountry == "Tanzania") { echo " selected"; } ?>>Tanzania
	<option value="Thailand"<?php if ($sCountry == "Thailand") { echo " selected"; } ?>>Thailand
	<option value="Togo"<?php if ($sCountry == "Togo") { echo " selected"; } ?>>Togo
	<option value="Tokelau"<?php if ($sCountry == "Tokelau") { echo " selected"; } ?>>Tokelau
	<option value="Tonga"<?php if ($sCountry == "Tonga") { echo " selected"; } ?>>Tonga
	<option value="Trinidad"<?php if ($sCountry == "Trinidad") { echo " selected"; } ?>>Trinidad
	<option value="Tunesia"<?php if ($sCountry == "Tunesia") { echo " selected"; } ?>>Tunesia
	<option value="Turkey"<?php if ($sCountry == "Turkey") { echo " selected"; } ?>>Turkey
	<option value="Turkmenistan"<?php if ($sCountry == "Turkmenistan") { echo " selected"; } ?>>Turkmenistan
	<option value="Turks and Caicos"<?php if ($sCountry == "Turks and Caicos") { echo " selected"; }?>>Turks and Caicos
	<option value="Tuvalu"<?php if ($sCountry == "Tuvalu") { echo " selected"; } ?>>Tuvalu
	<option value="Uganda"<?php if ($sCountry == "Uganda") { echo " selected"; } ?>>Uganda
	<option value="Ukraine"<?php if ($sCountry == "Ukraine") { echo " selected"; } ?>>Ukraine
	<option value="United Arab Emirates"<?php if ($sCountry == "United Arab Emirates") { echo " selected"; }?>>United Arab Emir
	<option value="Uruguay"<?php if ($sCountry == "Uruguay") { echo " selected"; } ?>>Uruguay
	<option value="US Minor Outlying"<?php if ($sCountry == "US Minor Outlying") { echo " selected"; }?>>US Minor Outlyin
	<option value="US Virgin Island"<?php if ($sCountry == "US Virgin Island") { echo " selected"; }?>>US Virgin Island
	<option value="Uzbekistan"<?php if ($sCountry == "Uzbekistan") { echo " selected"; } ?>>Uzbekistan
	<option value="Vanuatu"<?php if ($sCountry == "Vanuatu") { echo " selected"; } ?>>Vanuatu
	<option value="Vatican City"<?php if ($sCountry == "Vatican City") { echo " selected"; }?>>Vatican City
	<option value="Venezuela"<?php if ($sCountry == "Venezuela") { echo " selected"; } ?>>Venezuela
	<option value="Vietnam"<?php if ($sCountry == "Vietnam") { echo " selected"; } ?>>Vietnam
	<option value="Wallis and Futun"<?php if ($sCountry == "Wallis and Futun") { echo " selected"; }?>>Wallis and Futun
	<option value="Western Sahara"<?php if ($sCountry == "Western Sahara") { echo " selected"; }?>>Western Sahara
	<option value="Yemen"<?php if ($sCountry == "Yemen") { echo " selected"; } ?>>Yemen
	<option value="Yugoslavia"<?php if ($sCountry == "Yugoslavia") { echo " selected"; } ?>>Yugoslavia
	<option value="Zaire"<?php if ($sCountry == "Zaire") { echo " selected"; } ?>>Zaire
	<option value="Zambia"<?php if ($sCountry == "Zambia") { echo " selected"; } ?>>Zambia
	<option value="Zimbabwe"<?php if ($sCountry == "Zimbabwe") { echo " selected"; } ?>>Zimbabwe
	<option value="Other"<?php if ($sCountry == "Other") { echo " selected"; } ?>>Other/Not Listed
</select>
