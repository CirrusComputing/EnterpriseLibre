<?php

// Echo merchant account information goes here

// To obtain an Echo account start here:
// http://www.echo-inc.com/accept-donation-payments-online.html

// They will quickly issue test accounts which will do everything except actually
// perform transactions.  The test account can do credit card checks, including name
// and address verification so it is possible to evaluate just about everything with
// a test account.

$EchoAccount = "123>4567890";
$EchoPin = "12345678";
$EchoPayee = "Your church name here";

?>
