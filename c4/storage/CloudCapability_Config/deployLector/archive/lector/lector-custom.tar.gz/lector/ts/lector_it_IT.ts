<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="it" sourcelanguage="">
<context>
    <name>EditorBar</name>
    <message>
        <location filename="editor/textwidget.py" line="53"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="58"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="63"/>
        <source>Spellchecking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="71"/>
        <source>Show whitespace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="78"/>
        <source>&amp;Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="85"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="92"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="99"/>
        <source>Strikethrough</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="105"/>
        <source>Subscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="111"/>
        <source>Superscript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Lector</name>
    <message>
        <location filename="ui/ui_lector.ui" line="14"/>
        <source>Lector</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="74"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="263"/>
        <source>Exit</source>
        <translation>Esci</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="272"/>
        <source>Rotate right</source>
        <translation>Ruota a destra</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="284"/>
        <source>Rotate left</source>
        <translation>Ruota a sinistra</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="296"/>
        <source>Flip</source>
        <translation>Ribalta</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="308"/>
        <source>Zoom in</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="320"/>
        <source>Zoom out</source>
        <translation>Rimpicciolisci</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="332"/>
        <source>Read</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="149"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="215"/>
        <source>Text</source>
        <translation>Testo</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="251"/>
        <source>&amp;Open image</source>
        <translation>&amp;Apri immagine</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="254"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../ui/ui_lector.ui" line="254"/>
        <source>View</source>
        <translation type="obsolete">Visualizza</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="311"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="323"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../ui/ui_lector.ui" line="323"/>
        <source>Save &amp;as</source>
        <translation type="obsolete">Sa&amp;lva con nome</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="168"/>
        <source>New area</source>
        <translation>Nuova area</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="222"/>
        <source>Image</source>
        <translation>Immagine</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="344"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="33"/>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="43"/>
        <source>&amp;View</source>
        <translation>&amp;Visualizza</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="50"/>
        <source>&amp;Edit</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="275"/>
        <source>Ctrl+Right</source>
        <translation>Ctrl+Right</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="287"/>
        <source>Ctrl+Left</source>
        <translation>Ctrl+Left</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="299"/>
        <source>Ctrl+Down</source>
        <translation>Ctrl+Down</translation>
    </message>
    <message>
        <location filename="../ui/ui_lector.ui" line="299"/>
        <source>Save text &amp;as</source>
        <translation type="obsolete">Salva &amp;testo come</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="353"/>
        <source>Scan</source>
        <translation>Scansiona</translation>
    </message>
    <message>
        <location filename="../ui/ui_lector.ui" line="353"/>
        <source>Save image as</source>
        <translation type="obsolete">Salva immagine come</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="200"/>
        <source>Change selected area type</source>
        <translation>Cambia il tipo dell&apos;area selezionata</translation>
    </message>
    <message>
        <location filename="../ui/ui_lector.ui" line="200"/>
        <source>Change area</source>
        <translation type="obsolete">Cambia </translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="203"/>
        <source>Edit area</source>
        <translation>Modifica area</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="61"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="158"/>
        <source>Please select language for OCR</source>
        <translation>Seleziona la lingua dell&apos;OCR</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="372"/>
        <source>About Lector...</source>
        <translation>Informazioni su Lector</translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="386"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="377"/>
        <source>Change Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="121"/>
        <source>OCR results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="341"/>
        <source>Save text &amp;as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_lector.ui" line="362"/>
        <source>Save image as...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QOcrWidget</name>
    <message>
        <location filename="ocrarea.py" line="57"/>
        <source>Remove</source>
        <translation type="unfinished">Elimina</translation>
    </message>
    <message>
        <location filename="ocrarea.py" line="60"/>
        <source>Text</source>
        <translation type="unfinished">Testo</translation>
    </message>
    <message>
        <location filename="ocrarea.py" line="61"/>
        <source>Graphics</source>
        <translation type="unfinished">Grafica</translation>
    </message>
    <message>
        <location filename="ocrwidget.py" line="265"/>
        <source>Processing images...</source>
        <translation type="unfinished">Elaborazione immagini...</translation>
    </message>
    <message>
        <location filename="ocrwidget.py" line="263"/>
        <source>Abort</source>
        <translation type="unfinished">Interrompi</translation>
    </message>
</context>
<context>
    <name>Scanner</name>
    <message>
        <location filename="ui/ui_scanner.ui" line="14"/>
        <source>Select scanner</source>
        <translation type="unfinished">Scegli scanner</translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="23"/>
        <source>Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="35"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="41"/>
        <source>Width (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="58"/>
        <source>Height (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="78"/>
        <source>Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="84"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="91"/>
        <source>Color mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="106"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="111"/>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_scanner.ui" line="116"/>
        <source>Lineart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerThread</name>
    <message>
        <location filename="scannerthread.py" line="67"/>
        <source>Abort</source>
        <translation type="unfinished">Interrompi</translation>
    </message>
    <message>
        <location filename="scannerthread.py" line="67"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scannerthread.py" line="70"/>
        <source>Scanning...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="ui/ui_settings.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="26"/>
        <source>Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="32"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="38"/>
        <source>Width (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="55"/>
        <source>Height (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="75"/>
        <source>Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="84"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="98"/>
        <source>Color mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="106"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="111"/>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="116"/>
        <source>Lineart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="320"/>
        <source>Tesseract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="153"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="141"/>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="207"/>
        <source>Clear editor before OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="159"/>
        <source>Name of used font for document editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="175"/>
        <source>Click here to change used font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="290"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="223"/>
        <source>Spell checker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="229"/>
        <source>Dictionary:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="243"/>
        <source>Directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="270"/>
        <source>Click here to set directory with your spellchecking dictionaries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="280"/>
        <source>Personal Word Lists:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="304"/>
        <source>Personal Word List based on dictionary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="311"/>
        <source>Enchant found. Spellchecker is enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="236"/>
        <source>List of found dictionaries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="253"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Directory where are placed your spellchecker dictionaries.&lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt; Leave blank&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; if you want to use only default Enchant dictionaries.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="30"/>
        <source>Enchant not found. Check if pyenchant is installed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="33"/>
        <source>Enchant found but no dictionary. Check your dictionary directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="45"/>
        <source>&apos;%s&apos; was not found in available dictionaries. Using other dictionary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="67"/>
        <source>Choose your font...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="74"/>
        <source>Choose your dictionary directory...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="85"/>
        <source>Select your private dictionary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.py" line="85"/>
        <source>Dictionary (*.txt *.dic);;All files (*);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_settings.ui" line="297"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;If this option is checked and your &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;Personal Word List&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; is set to e.g. &amp;quot;/home/user/my_dict.txt&amp;quot;, than Lector will use as &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;Personal Word List&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; for &amp;quot;en_GB&amp;quot; dictionary &amp;quot;/home/user/en_GB_my_dict.txt&amp;quot;, so you will have individual &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;Personal Word List&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;  file per used dictionary.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextWidget</name>
    <message>
        <location filename="editor/textwidget.py" line="495"/>
        <source>Save document</source>
        <translation type="unfinished">Salva documento</translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="338"/>
        <source>to Capitalize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="359"/>
        <source>Spelling Suggestions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="360"/>
        <source>Add word...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="495"/>
        <source>ODT document (*.odt);;Text file (*.txt);;HTML file (*.html);;PDF file(*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="523"/>
        <source>Open File...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="523"/>
        <source>HTML-Files (*.htm *.html);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="542"/>
        <source>Error - Lector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="306"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="314"/>
        <source>Text change...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="316"/>
        <source>Join lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="323"/>
        <source>to UPPERCASE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="328"/>
        <source>to lowercase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="333"/>
        <source>to Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="534"/>
        <source>Can&apos;t open &apos;%s.&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="editor/textwidget.py" line="542"/>
        <source>&apos;%s&apos; is not a file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="lector.pyw" line="66"/>
        <source>Ready</source>
        <translation type="unfinished">Pronto</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="206"/>
        <source>Open image</source>
        <translation type="unfinished">Apri immagine</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>Images (*.png *.xpm *.jpg)</source>
        <translation type="obsolete">Immagini (*.png *.xpm *.jpg)</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="299"/>
        <source>Are you sure you want to exit?</source>
        <translation type="unfinished">Sei sicuro di voler uscire?</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>Save document</source>
        <translation type="obsolete">Salva documento</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>RTF document</source>
        <translation type="obsolete">Documento RTF</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="107"/>
        <source>English</source>
        <translation type="unfinished">Inglese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="115"/>
        <source>Italian</source>
        <translation type="unfinished">Italiano</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="110"/>
        <source>German</source>
        <translation type="unfinished">Tedesco</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="106"/>
        <source>Dutch</source>
        <translation type="unfinished">Dutch</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="109"/>
        <source>French</source>
        <translation type="unfinished">Francese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="128"/>
        <source>Spanish</source>
        <translation type="unfinished">Spagnolo</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>Select scanner</source>
        <translation type="obsolete">Scegli scanner</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="316"/>
        <source>Save image</source>
        <translation type="unfinished">Salva immagine</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>PNG document</source>
        <translation type="obsolete">documento PNG</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>PNG image</source>
        <translation type="obsolete">Immagine PNG</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="99"/>
        <source>Bulgarian</source>
        <translation type="unfinished">Bulgaro</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="100"/>
        <source>Catalan</source>
        <translation type="unfinished">Catalano</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="101"/>
        <source>Czech</source>
        <translation type="unfinished">Ceco</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="102"/>
        <source>Chinese (Traditional)</source>
        <translation type="unfinished">Cinese (tradizionale)</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="103"/>
        <source>Chinese (Simplified)</source>
        <translation type="unfinished">Cinese (semplificato)</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="104"/>
        <source>Danish</source>
        <translation type="unfinished">Danese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="108"/>
        <source>Finnish</source>
        <translation type="unfinished">Finlandese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="112"/>
        <source>Greek</source>
        <translation type="unfinished">Greco</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="113"/>
        <source>Hungarian</source>
        <translation type="unfinished">Ungherese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="114"/>
        <source>Indonesian</source>
        <translation type="unfinished">Indonesiano</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="116"/>
        <source>Japanese</source>
        <translation type="unfinished">Giapponese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="117"/>
        <source>Korean</source>
        <translation type="unfinished">Coreano</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="118"/>
        <source>Latvian</source>
        <translation type="unfinished">Lettone</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="119"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Lituano</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="120"/>
        <source>Norwegian</source>
        <translation type="unfinished">Norvegese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="121"/>
        <source>Polish</source>
        <translation type="unfinished">Polacco</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="122"/>
        <source>Portuguese</source>
        <translation type="unfinished">Portoghese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="123"/>
        <source>Romanian</source>
        <translation type="unfinished">Rumeno</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="124"/>
        <source>Russian</source>
        <translation type="unfinished">Russo</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="125"/>
        <source>Slovak</source>
        <translation type="unfinished">Slovacco</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="127"/>
        <source>Slovenian</source>
        <translation type="unfinished">Sloveno</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="129"/>
        <source>Serbian</source>
        <translation type="unfinished">Serbo</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="130"/>
        <source>Swedish</source>
        <translation type="unfinished">Svedese</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="133"/>
        <source>Turkish</source>
        <translation type="unfinished">Turco</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="134"/>
        <source>Ukrainian</source>
        <translation type="unfinished">Ucraino</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="135"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamita</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="206"/>
        <source>Images (*.tif *.tiff *.png *.bmp *.jpg *.xpm)</source>
        <translation type="unfinished">Immagini (*.tif *.tiff *.png *.bmp *.jpg *.xpm)</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="330"/>
        <source>About Lector</source>
        <translation type="unfinished">Informazioni su Lector</translation>
    </message>
    <message>
        <location filename="../ui/ui_settings.ui" line="294"/>
        <source>ODT document</source>
        <translation type="obsolete">Documento ODT</translation>
    </message>
    <message>
        <location filename="lector.pyw" line="91"/>
        <source>Tessaract not available. Please check requirements.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="105"/>
        <source>Danish (Fraktur)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="111"/>
        <source>German (Fraktur)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="126"/>
        <source>Slovak (Fraktur)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="131"/>
        <source>Swedish (Fraktur)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="132"/>
        <source>Tagalog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="299"/>
        <source>Lector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="306"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="307"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="316"/>
        <source>PNG image (*.png);;TIFF image (*.tif *.tiff);;BMP image (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lector.pyw" line="330"/>
        <source>&lt;p&gt;The &lt;b&gt;Lector&lt;/b&gt; is a graphical ocr solution for GNU/Linux and Windows based on Python, Qt4 and tessaract OCR.&lt;/p&gt;&lt;p&gt;Scanning option is available only on GNU/Linux via SANE.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Author:&lt;/b&gt; Davide Setti&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Contributors:&lt;/b&gt; chopinX04, filip.dominec, zdposter&lt;/p&gt;&lt;p&gt;&lt;b&gt;Web site:&lt;/b&gt; http://code.google.com/p/lector&lt;/p&gt;&lt;p&gt;&lt;b&gt;Source code:&lt;/b&gt; http://code.google.com/p/lector/source/checkout&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
