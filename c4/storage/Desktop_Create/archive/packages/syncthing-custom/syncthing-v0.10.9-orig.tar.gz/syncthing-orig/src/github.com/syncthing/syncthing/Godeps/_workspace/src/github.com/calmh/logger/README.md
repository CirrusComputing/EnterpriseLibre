logger
======

A small wrapper around `log` to provide log levels.

Documentation
-------------

http://godoc.org/github.com/calmh/logger

License
-------

MIT

