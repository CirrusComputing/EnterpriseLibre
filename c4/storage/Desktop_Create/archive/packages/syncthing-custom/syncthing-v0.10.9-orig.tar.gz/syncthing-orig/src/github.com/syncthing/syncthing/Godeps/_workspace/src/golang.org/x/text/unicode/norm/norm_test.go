// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package norm_test

import (
	"testing"
)

func TestPlaceHolder(t *testing.T) {
	// Does nothing, just allows the Makefile to be canonical
	// while waiting for the package itself to be written.
}
