
void *return_header_function();
void *return_write_function();
void *return_read_function();

void *return_progress_function();
