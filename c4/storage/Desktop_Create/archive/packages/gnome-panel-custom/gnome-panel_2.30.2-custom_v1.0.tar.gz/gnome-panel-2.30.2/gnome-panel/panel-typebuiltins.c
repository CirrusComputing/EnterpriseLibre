
/* Generated data (by glib-mkenums) */

#include <glib-object.h>
#include "panel-typebuiltins.h"


/* enumerations from "../gnome-panel/panel-enums.h" */
#include "../gnome-panel/panel-enums.h"
static const GEnumValue _panel_orientation_values[] = {
  { PANEL_ORIENTATION_TOP, "PANEL_ORIENTATION_TOP", "top" },
  { PANEL_ORIENTATION_RIGHT, "PANEL_ORIENTATION_RIGHT", "right" },
  { PANEL_ORIENTATION_BOTTOM, "PANEL_ORIENTATION_BOTTOM", "bottom" },
  { PANEL_ORIENTATION_LEFT, "PANEL_ORIENTATION_LEFT", "left" },
  { 0, NULL, NULL }
};

GType
panel_orientation_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelOrientation", _panel_orientation_values);

  return type;
}

static const GEnumValue _panel_frame_edge_values[] = {
  { PANEL_EDGE_NONE, "PANEL_EDGE_NONE", "none" },
  { PANEL_EDGE_TOP, "PANEL_EDGE_TOP", "top" },
  { PANEL_EDGE_BOTTOM, "PANEL_EDGE_BOTTOM", "bottom" },
  { PANEL_EDGE_LEFT, "PANEL_EDGE_LEFT", "left" },
  { PANEL_EDGE_RIGHT, "PANEL_EDGE_RIGHT", "right" },
  { 0, NULL, NULL }
};

GType
panel_frame_edge_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelFrameEdge", _panel_frame_edge_values);

  return type;
}

static const GEnumValue _panel_state_values[] = {
  { PANEL_STATE_NORMAL, "PANEL_STATE_NORMAL", "normal" },
  { PANEL_STATE_AUTO_HIDDEN, "PANEL_STATE_AUTO_HIDDEN", "auto-hidden" },
  { PANEL_STATE_HIDDEN_UP, "PANEL_STATE_HIDDEN_UP", "hidden-up" },
  { PANEL_STATE_HIDDEN_DOWN, "PANEL_STATE_HIDDEN_DOWN", "hidden-down" },
  { PANEL_STATE_HIDDEN_LEFT, "PANEL_STATE_HIDDEN_LEFT", "hidden-left" },
  { PANEL_STATE_HIDDEN_RIGHT, "PANEL_STATE_HIDDEN_RIGHT", "hidden-right" },
  { 0, NULL, NULL }
};

GType
panel_state_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelState", _panel_state_values);

  return type;
}

static const GEnumValue _panel_animation_speed_values[] = {
  { PANEL_ANIMATION_SLOW, "PANEL_ANIMATION_SLOW", "slow" },
  { PANEL_ANIMATION_MEDIUM, "PANEL_ANIMATION_MEDIUM", "medium" },
  { PANEL_ANIMATION_FAST, "PANEL_ANIMATION_FAST", "fast" },
  { 0, NULL, NULL }
};

GType
panel_animation_speed_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelAnimationSpeed", _panel_animation_speed_values);

  return type;
}

static const GEnumValue _panel_background_type_values[] = {
  { PANEL_BACK_NONE, "PANEL_BACK_NONE", "none" },
  { PANEL_BACK_COLOR, "PANEL_BACK_COLOR", "color" },
  { PANEL_BACK_IMAGE, "PANEL_BACK_IMAGE", "image" },
  { 0, NULL, NULL }
};

GType
panel_background_type_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelBackgroundType", _panel_background_type_values);

  return type;
}

static const GEnumValue _panel_gconf_key_type_values[] = {
  { PANEL_GCONF_TOPLEVELS, "PANEL_GCONF_TOPLEVELS", "toplevels" },
  { PANEL_GCONF_OBJECTS, "PANEL_GCONF_OBJECTS", "objects" },
  { PANEL_GCONF_APPLETS, "PANEL_GCONF_APPLETS", "applets" },
  { 0, NULL, NULL }
};

GType
panel_gconf_key_type_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelGConfKeyType", _panel_gconf_key_type_values);

  return type;
}

static const GEnumValue _panel_object_type_values[] = {
  { PANEL_OBJECT_DRAWER, "PANEL_OBJECT_DRAWER", "drawer" },
  { PANEL_OBJECT_MENU, "PANEL_OBJECT_MENU", "menu" },
  { PANEL_OBJECT_LAUNCHER, "PANEL_OBJECT_LAUNCHER", "launcher" },
  { PANEL_OBJECT_BONOBO, "PANEL_OBJECT_BONOBO", "bonobo" },
  { PANEL_OBJECT_ACTION, "PANEL_OBJECT_ACTION", "action" },
  { PANEL_OBJECT_MENU_BAR, "PANEL_OBJECT_MENU_BAR", "menu-bar" },
  { PANEL_OBJECT_SEPARATOR, "PANEL_OBJECT_SEPARATOR", "separator" },
  { PANEL_OBJECT_LOGOUT, "PANEL_OBJECT_LOGOUT", "logout" },
  { PANEL_OBJECT_LOCK, "PANEL_OBJECT_LOCK", "lock" },
  { 0, NULL, NULL }
};

GType
panel_object_type_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelObjectType", _panel_object_type_values);

  return type;
}

static const GEnumValue _panel_action_button_type_values[] = {
  { PANEL_ACTION_NONE, "PANEL_ACTION_NONE", "none" },
  { PANEL_ACTION_LOCK, "PANEL_ACTION_LOCK", "lock" },
  { PANEL_ACTION_LOGOUT, "PANEL_ACTION_LOGOUT", "logout" },
  { PANEL_ACTION_RUN, "PANEL_ACTION_RUN", "run" },
  { PANEL_ACTION_SEARCH, "PANEL_ACTION_SEARCH", "search" },
  { PANEL_ACTION_FORCE_QUIT, "PANEL_ACTION_FORCE_QUIT", "force-quit" },
  { PANEL_ACTION_CONNECT_SERVER, "PANEL_ACTION_CONNECT_SERVER", "connect-server" },
  { PANEL_ACTION_SHUTDOWN, "PANEL_ACTION_SHUTDOWN", "shutdown" },
  { PANEL_ACTION_SCREENSHOT, "PANEL_ACTION_SCREENSHOT", "screenshot" },
  { PANEL_ACTION_LAST, "PANEL_ACTION_LAST", "last" },
  { 0, NULL, NULL }
};

GType
panel_action_button_type_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelActionButtonType", _panel_action_button_type_values);

  return type;
}


/* enumerations from "../gnome-panel/panel-types.h" */
#include "../gnome-panel/panel-types.h"
static const GEnumValue _panel_size_values[] = {
  { PANEL_SIZE_XX_SMALL, "PANEL_SIZE_XX_SMALL", "xx-small" },
  { PANEL_SIZE_X_SMALL, "PANEL_SIZE_X_SMALL", "x-small" },
  { PANEL_SIZE_SMALL, "PANEL_SIZE_SMALL", "small" },
  { PANEL_SIZE_MEDIUM, "PANEL_SIZE_MEDIUM", "medium" },
  { PANEL_SIZE_LARGE, "PANEL_SIZE_LARGE", "large" },
  { PANEL_SIZE_X_LARGE, "PANEL_SIZE_X_LARGE", "x-large" },
  { PANEL_SIZE_XX_LARGE, "PANEL_SIZE_XX_LARGE", "xx-large" },
  { 0, NULL, NULL }
};

GType
panel_size_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelSize", _panel_size_values);

  return type;
}

static const GEnumValue _panel_speed_values[] = {
  { PANEL_SPEED_SLOW, "PANEL_SPEED_SLOW", "slow" },
  { PANEL_SPEED_MEDIUM, "PANEL_SPEED_MEDIUM", "medium" },
  { PANEL_SPEED_FAST, "PANEL_SPEED_FAST", "fast" },
  { 0, NULL, NULL }
};

GType
panel_speed_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelSpeed", _panel_speed_values);

  return type;
}


/* enumerations from "GNOME_Panel.h" */
#include "GNOME_Panel.h"
static const GEnumValue _g_nome__vertigo__panel_applet_shell__imethods_index_values[] = {
  { GNOME_Vertigo_PanelAppletShell_popup_menu__imethods_index, "GNOME_Vertigo_PanelAppletShell_popup_menu__imethods_index", "index" },
  { 0, NULL, NULL }
};

GType
g_nome__vertigo__panel_applet_shell__imethods_index_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("GNOME_Vertigo_PanelAppletShell__imethods_index", _g_nome__vertigo__panel_applet_shell__imethods_index_values);

  return type;
}


/* Generated data ends here */

