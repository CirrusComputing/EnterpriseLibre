
#ifndef __panel_applet_marshal_MARSHAL_H__
#define __panel_applet_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:ENUM,BOXED,OBJECT (panel-applet-marshal.list:1) */
extern void panel_applet_marshal_VOID__ENUM_BOXED_OBJECT (GClosure     *closure,
                                                          GValue       *return_value,
                                                          guint         n_param_values,
                                                          const GValue *param_values,
                                                          gpointer      invocation_hint,
                                                          gpointer      marshal_data);

/* VOID:INT (panel-applet-marshal.list:2) */
#define panel_applet_marshal_VOID__INT	g_cclosure_marshal_VOID__INT

/* VOID:UINT (panel-applet-marshal.list:3) */
#define panel_applet_marshal_VOID__UINT	g_cclosure_marshal_VOID__UINT

/* VOID:ENUM (panel-applet-marshal.list:4) */
#define panel_applet_marshal_VOID__ENUM	g_cclosure_marshal_VOID__ENUM

/* BOOLEAN:STRING (panel-applet-marshal.list:5) */
extern void panel_applet_marshal_BOOLEAN__STRING (GClosure     *closure,
                                                  GValue       *return_value,
                                                  guint         n_param_values,
                                                  const GValue *param_values,
                                                  gpointer      invocation_hint,
                                                  gpointer      marshal_data);

G_END_DECLS

#endif /* __panel_applet_marshal_MARSHAL_H__ */

