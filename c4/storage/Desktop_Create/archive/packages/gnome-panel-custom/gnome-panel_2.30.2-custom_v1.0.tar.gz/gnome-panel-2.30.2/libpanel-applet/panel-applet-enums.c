
/* Generated data (by glib-mkenums) */

#include <glib-object.h>
#include "panel-applet-enums.h"


/* enumerations from "../libpanel-applet/panel-applet.h" */
#include "../libpanel-applet/panel-applet.h"
static const GEnumValue _panel_applet_background_type_values[] = {
  { PANEL_NO_BACKGROUND, "PANEL_NO_BACKGROUND", "no-background" },
  { PANEL_COLOR_BACKGROUND, "PANEL_COLOR_BACKGROUND", "color-background" },
  { PANEL_PIXMAP_BACKGROUND, "PANEL_PIXMAP_BACKGROUND", "pixmap-background" },
  { 0, NULL, NULL }
};

GType
panel_applet_background_type_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_enum_register_static ("PanelAppletBackgroundType", _panel_applet_background_type_values);

  return type;
}

static const GFlagsValue _panel_applet_flags_values[] = {
  { PANEL_APPLET_FLAGS_NONE, "PANEL_APPLET_FLAGS_NONE", "flags-none" },
  { PANEL_APPLET_EXPAND_MAJOR, "PANEL_APPLET_EXPAND_MAJOR", "expand-major" },
  { PANEL_APPLET_EXPAND_MINOR, "PANEL_APPLET_EXPAND_MINOR", "expand-minor" },
  { PANEL_APPLET_HAS_HANDLE, "PANEL_APPLET_HAS_HANDLE", "has-handle" },
  { 0, NULL, NULL }
};

GType
panel_applet_flags_get_type (void)
{
  static GType type = 0;

  if (!type)
    type = g_flags_register_static ("PanelAppletFlags", _panel_applet_flags_values);

  return type;
}


/* Generated data ends here */

