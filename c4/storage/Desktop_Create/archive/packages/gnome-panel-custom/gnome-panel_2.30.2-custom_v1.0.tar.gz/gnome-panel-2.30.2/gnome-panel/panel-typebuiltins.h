
/* Generated data (by glib-mkenums) */

#ifndef __PANEL_TYPEBUILTINS_H__
#define __PANEL_TYPEBUILTINS_H__ 1

G_BEGIN_DECLS


/* --- ../gnome-panel/panel-enums.h --- */
#define PANEL_TYPE_ORIENTATION panel_orientation_get_type()
GType panel_orientation_get_type (void);
#define PANEL_TYPE_FRAME_EDGE panel_frame_edge_get_type()
GType panel_frame_edge_get_type (void);
#define PANEL_TYPE_STATE panel_state_get_type()
GType panel_state_get_type (void);
#define PANEL_TYPE_ANIMATION_SPEED panel_animation_speed_get_type()
GType panel_animation_speed_get_type (void);
#define PANEL_TYPE_BACKGROUND_TYPE panel_background_type_get_type()
GType panel_background_type_get_type (void);
#define PANEL_TYPE_GCONF_KEY_TYPE panel_gconf_key_type_get_type()
GType panel_gconf_key_type_get_type (void);
#define PANEL_TYPE_OBJECT_TYPE panel_object_type_get_type()
GType panel_object_type_get_type (void);
#define PANEL_TYPE_ACTION_BUTTON_TYPE panel_action_button_type_get_type()
GType panel_action_button_type_get_type (void);

/* --- ../gnome-panel/panel-types.h --- */
#define PANEL_TYPE_SIZE panel_size_get_type()
GType panel_size_get_type (void);
#define PANEL_TYPE_SPEED panel_speed_get_type()
GType panel_speed_get_type (void);

/* --- GNOME_Panel.h --- */
#define PANEL_TYPE_NOME__VERTIGO__PANEL_APPLET_SHELL__IMETHODS_INDEX g_nome__vertigo__panel_applet_shell__imethods_index_get_type()
GType g_nome__vertigo__panel_applet_shell__imethods_index_get_type (void);
G_END_DECLS

#endif /* __PANEL_TYPEBUILTINS_H__ */

/* Generated data ends here */

