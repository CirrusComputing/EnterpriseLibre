


#ifndef __CLOCK_TYPEBUILTINS_H__
#define __CLOCK_TYPEBUILTINS_H__ 1

G_BEGIN_DECLS


/* --- ../../applets/clock/clock-utils.h --- */
#define CLOCK_TYPE_FORMAT clock_format_get_type()
GType clock_format_get_type (void);
G_END_DECLS

#endif /* __CLOCK_TYPEBUILTINS_H__ */



