
/* Generated data (by glib-mkenums) */

#ifndef __PANEL_APPLET_ENUMS_H__
#define __PANEL_APPLET_ENUMS_H__

G_BEGIN_DECLS


/* --- ../libpanel-applet/panel-applet.h --- */
#define PANEL_TYPE_PANEL_APPLET_BACKGROUND_TYPE panel_applet_background_type_get_type()
GType panel_applet_background_type_get_type (void);
#define PANEL_TYPE_PANEL_APPLET_FLAGS panel_applet_flags_get_type()
GType panel_applet_flags_get_type (void);
G_END_DECLS

#endif /* __PANEL_APPLET_ENUMS_H__ */

/* Generated data ends here */

