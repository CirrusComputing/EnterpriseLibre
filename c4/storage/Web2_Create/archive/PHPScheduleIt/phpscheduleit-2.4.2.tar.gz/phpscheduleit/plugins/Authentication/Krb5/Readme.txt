
The Krb5 authentication method is obsolete - it has been replaced by the Apache plugin. 

